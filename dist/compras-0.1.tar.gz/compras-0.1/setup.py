from setuptools import setup, find_packages

setup(
    name='compras',
    version='0.1',
    description= "Modelo de clientes para venta",
    author= "Waira C",
    packages=find_packages(),
    install_requires=[],
    )